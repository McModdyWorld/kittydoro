const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  // Create the browser window - wider instead of tall
  mainWindow = new BrowserWindow({
    width: 700,
    height: 500,
    resizable: false,
    fullscreenable: false,
    frame: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'assets', 'app-icon.png')
  });

  // Load the index.html of the app
  mainWindow.loadFile('index.html');

  // Development - Open the DevTools
  if (process.argv.includes('--dev')) {
    mainWindow.webContents.openDevTools({ mode: 'detach' });
    console.log('Developer mode active - DevTools opened');
  }
  
  console.log('Main window created');
}

// Direct IPC listeners for window controls
ipcMain.on('close-app', () => {
  console.log('Close app message received');
  app.quit();
});

ipcMain.on('minimize-app', () => {
  console.log('Minimize app message received');
  if (mainWindow) mainWindow.minimize();
});

// Create window when Electron is ready
app.whenReady().then(() => {
  console.log('Electron app ready');
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

// Quit when all windows are closed, except on macOS
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});