// DOM Elements
const minimizeBtn = document.getElementById('minimize-btn');
const closeBtn = document.getElementById('close-btn');
const locationName = document.getElementById('location-name');
const weatherIcon = document.getElementById('weather-icon');
const currentTemp = document.getElementById('current-temp');
const tempUnit = document.getElementById('temp-unit');
const weatherDescription = document.getElementById('weather-description');
const feelsLikeTemp = document.getElementById('feels-like-temp');
const humidity = document.getElementById('humidity');
const wind = document.getElementById('wind');
const precipitation = document.getElementById('precipitation');
const cloudCover = document.getElementById('cloud-cover');
const forecast = document.getElementById('forecast');

// App state
let weatherData = null;

// Simple weather icons
const weatherIcons = {
  sunny: 'sunny-pixel-art-48.svg',
  cloudy: 'cloudy-pixel-art-48.svg',
  rainy: 'rainy-pixel-art-48.svg',
  snowy: 'snowy-pixel-art-48.svg',
  thunderstorm: 'thunderstorm-pixel-art-48.svg'
};

// Initialize app
async function init() {
  console.log('App initializing...');
  
  // Default location name while loading
  locationName.textContent = 'Detecting location...';
  
  // Add event listeners
  setupEventListeners();
  
  // Get user's location via IP and load weather data
  getIPBasedLocation();
}

// Set up event listeners
function setupEventListeners() {
  // Direct button click handlers
  if (minimizeBtn) {
    minimizeBtn.addEventListener('click', () => {
      console.log('Minimize button clicked');
      // Use electron's direct ipcRenderer
      if (window.electron) {
        window.electron.send('minimize-app');
      }
    });
  }
  
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      console.log('Close button clicked');
      // Use electron's direct ipcRenderer
      if (window.electron) {
        window.electron.send('close-app');
      }
    });
  }
}

// Get user's location using an IP geolocation service
async function getIPBasedLocation() {
  try {
    weatherDescription.textContent = 'Detecting your location...';
    weatherIcon.innerHTML = '<div class="loading-icon">🔄</div>';
    
    // Use a free IP geolocation service
    const response = await fetch('https://ipapi.co/json/');
    const data = await response.json();
    
    if (data && data.latitude && data.longitude) {
      console.log(`IP location detected: ${data.city}, ${data.country_name}`);
      
      // Set location name
      locationName.textContent = `${data.city}, ${data.country_name}`;
      
      // Fetch weather with detected coordinates
      fetchWeatherData(data.latitude, data.longitude);
    } else {
      throw new Error('Invalid location data');
    }
  } catch (error) {
    console.error('Error detecting location via IP:', error);
    weatherDescription.textContent = 'Could not detect your location';
    
    // Fallback to Vienna if IP geolocation fails
    locationName.textContent = 'Vienna, Austria';
    fetchWeatherData(48.2082, 16.3738);
  }
}

// Fetch weather data from API
async function fetchWeatherData(latitude, longitude) {
  console.log(`Fetching weather data for coordinates: ${latitude}, ${longitude}`);
  try {
    weatherDescription.textContent = 'Loading weather data...';
    
    // Try to use the window.fetch API
    try {
      const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=temperature_2m`);
      weatherData = await response.json();
      console.log('Weather data received:', weatherData);
    } catch (fetchError) {
      console.error('Error using fetch API:', fetchError);
      // Fallback to sample data
      console.log('Using sample data');
      weatherData = {
        hourly: {
          temperature_2m: Array(24).fill(15) // 15 degrees for all hours
        }
      };
    }
    
    // Update UI with weather data
    updateWeatherUI();
  } catch (error) {
    console.error('Error fetching weather data:', error);
    weatherDescription.textContent = 'Failed to load weather data';
    weatherIcon.innerHTML = '❌';
  }
}

// Update UI with weather data
function updateWeatherUI() {
  console.log('Updating weather UI...');
  if (!weatherData || !weatherData.hourly || !weatherData.hourly.temperature_2m) {
    console.error('Invalid weather data format');
    weatherDescription.textContent = 'Invalid weather data format';
    return;
  }
  
  try {
    // Get current temperature from hourly data
    const currentTime = new Date();
    const currentHour = currentTime.getHours();
    let temp = 15; // Default temperature if data not available
    
    if (currentHour < weatherData.hourly.temperature_2m.length) {
      temp = weatherData.hourly.temperature_2m[currentHour];
    }
    
    console.log(`Current temperature: ${temp}°C`);
    
    // Choose weather icon based on temperature
    let icon = weatherIcons.sunny;
    let description = "Sunny Day";
    
    if (temp < 0) {
      icon = weatherIcons.snowy;
      description = "Snowy Day";
    } else if (temp < 10) {
      icon = weatherIcons.cloudy;
      description = "Cool and Cloudy";
    } else if (temp < 20) {
      icon = weatherIcons.cloudy;
      description = "Mild and Partly Cloudy";
    } else if (temp < 30) {
      icon = weatherIcons.sunny;
      description = "Warm and Sunny";
    } else {
      icon = weatherIcons.sunny;
      description = "Hot and Sunny";
    }
    
    // Update current weather
    document.getElementById('weather-icon').innerHTML = `<img src="assets/icons/${icon}" alt="${description}" class="pixelated">`;
    currentTemp.textContent = Math.round(temp);
    weatherDescription.textContent = description;
    
    // Set other weather details
    feelsLikeTemp.textContent = Math.round(temp);
    humidity.textContent = '45%';
    wind.textContent = '5 km/h';
    precipitation.textContent = '0 mm';
    cloudCover.textContent = '25%';
    
    // Update forecast
    updateForecast();
    console.log('Weather UI updated successfully');
  } catch (error) {
    console.error('Error updating weather UI:', error);
    weatherDescription.textContent = 'Error displaying weather';
  }
}

// Update forecast section
function updateForecast() {
  console.log('Updating forecast...');
  forecast.innerHTML = '';
  
  try {
    // Create forecast for each day (3 days)
    const days = ['Today', 'Tomorrow', 'Day After'];
    const icons = [
      weatherIcons.sunny, 
      weatherIcons.cloudy, 
      weatherIcons.rainy
    ];
    const descriptions = ['Sunny', 'Partly Cloudy', 'Chance of Rain'];
    const temperatures = [15, 14, 13]; // Default temperatures
    
    // Check if we have real data
    if (weatherData && weatherData.hourly && weatherData.hourly.temperature_2m) {
      // Get noon temperatures if available
      for (let i = 0; i < 3; i++) {
        const dayHour = (i * 24) + 12; // 12PM of each day
        if (dayHour < weatherData.hourly.temperature_2m.length) {
          temperatures[i] = weatherData.hourly.temperature_2m[dayHour];
        }
      }
    }
    
    // Create forecast items
    for (let i = 0; i < 3; i++) {
      const forecastItem = document.createElement('div');
      forecastItem.className = 'forecast-item';
      
      forecastItem.innerHTML = `
        <div class="forecast-day">${days[i]}</div>
        <img src="assets/icons/${icons[i]}" alt="${descriptions[i]}" class="forecast-icon pixelated">
        <div class="forecast-temp">${Math.round(temperatures[i])}°</div>
        <div class="forecast-desc">${descriptions[i]}</div>
      `;
      
      forecast.appendChild(forecastItem);
    }
    
    console.log('Forecast updated successfully');
  } catch (error) {
    console.error('Error updating forecast:', error);
  }
}

// Initialize app on load
window.addEventListener('DOMContentLoaded', init);