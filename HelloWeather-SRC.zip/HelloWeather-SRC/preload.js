const { contextBridge, ipcRenderer } = require('electron');

// Log that preload script is running
console.log('Preload script is running');

// Expose electron's IPC renderer directly for basic window controls
contextBridge.exposeInMainWorld('electron', {
  send: (channel, data) => {
    // Whitelist channels for security
    const validChannels = ['close-app', 'minimize-app'];
    if (validChannels.includes(channel)) {
      ipcRenderer.send(channel, data);
    }
  },
  receive: (channel, func) => {
    const validChannels = ['response'];
    if (validChannels.includes(channel)) {
      // Remove the event listener to avoid memory leaks
      ipcRenderer.removeAllListeners(channel);
      // Add a new listener
      ipcRenderer.on(channel, (_, ...args) => func(...args));
    }
  }
});

// Log when preload script has completed
console.log('Preload script has completed');